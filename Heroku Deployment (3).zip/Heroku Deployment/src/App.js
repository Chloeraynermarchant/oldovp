 
import React from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import Login from './components/login'
import SignUp from './components/signup'
import Profile from './components/profile'
import UploadContent from './components/upload_content'
import UploadedContent from './components/uploaded_content'
import Description from './components/description'
import Worktoolkit from './components/worktoolkit'
import Qualifier1 from './components/qualifier1'
import QualifiedProspects from './components/qualifiedprospects'
import Workflow from './components/myworkflow'
import UpdateUser from './components/updateUser'


import { Redirect } from "react-router-dom";




class Popup extends React.Component {
  render() {
    return (
      <div className="popup">
        <div className="popup_inner">
          <h2 style={{paddingTop:"10px"}}>Help</h2>
          <hr/>
          <p>
          If you are facing any problem  then you can contact with our different departments of our team.<br/>         
          </p>
          <h5>Administrators Contact : <small> adminhelp@solutionX.io</small> </h5> <br/>
          <h5>Managers Contact : <small> managerhelp@solutionX.io</small> </h5> <br/>
          <h5>Developers Contact : <small> developerhelp@solutionX.io</small> </h5> <br/>
          <button className="btn btn-primary btn-block" style={{width:'10%', float:'right', marginRight: '10px'}} onClick={this.props.closePopup}>Close</button>
        </div>
      </div>
    )
  }
}
class App extends React.Component {
  constructor() {
    super()
    this.state = {
      showPopup: false,
    }
  }
  togglePopup() {
    this.setState({
      showPopup: !this.state.showPopup,
    })
  }
  componentDidMount(){
    if (!localStorage.getItem("loggedIn")){
      return <Redirect to="/" />;
    }
  }
  handleLogout(){
    localStorage.clear();
    window.location.reload();
  }

  render() {

    return (
      <Router>
        <div className="App">
          <nav className="navbar navbar-expand-lg navbar-light fixed-top">
            <div className="container">
              <Link className="navbar-brand" to={'/sign-in'}>
                OVP Coaching Teams
              </Link>
              <div
                className="collapse navbar-collapse"
                id="navbarTogglerDemo02"
              >
                <ul className="navbar-nav ml-auto">
                  {localStorage.getItem('loggedin') !== 'true' ? (
                    <li className="nav-item">
                      <Link
                        onClick={this.togglePopup.bind(this)}
                        className="nav-link"
                        data-toggle="modal"
                        data-target=".help"
                      >
                        Help
                      </Link>
                      {this.state.showPopup ? (
                        <Popup closePopup={this.togglePopup.bind(this)}></Popup>
                      ) : null}
                    </li>
                  ) : (
                    <>
                      <li className="nav-item">
                        <Link className="nav-link" to={'/profile'}>
                          My Profile
                        </Link>
                      </li>
                      <li className="nav-item">
                        <Link className="nav-link" to={'/upload-content'}>
                          Learning
                        </Link>
                      </li>
                      <li className="nav-item">
                        <Link className="nav-link" to={'/worktoolkit'}>
                          Work Toolkit
                        </Link>
                      </li>
                      <li className="nav-item" >
                        <Link className="nav-link" onClick={(e)=>{e.preventDefault(); this.handleLogout()}}>
                          Logout
                        </Link>
                      </li>
                    </>
                  )}
                </ul>
              </div>
            </div>
          </nav>

          <div className="auth-wrapper">
            <div className="auth-inner">
              <Switch>
                <Route exact path="/" component={Login} />
                <Route path="/sign-in" component={Login} />
                <Route path="/sign-up" component={SignUp} />
                <Route path="/profile" component={Profile} />
                <Route path="/upload-content" component={UploadContent} />
                <Route path="/uploaded-content" component={UploadedContent} />
                <Route path={`/description/:id`}  component={Description} />
                <Route path="/worktoolkit" component={Worktoolkit} />
                <Route path="/qualifier1" component={Qualifier1} />
                <Route path="/qualifiedprospect" component={QualifiedProspects} />
                <Route path="/myworkflow" component={Workflow} />
                <Route path="/updatestudent/:name" component={UpdateUser} />
              </Switch>
            </div>
          </div>
        </div>
      </Router>
    )
  }
}

export default App
