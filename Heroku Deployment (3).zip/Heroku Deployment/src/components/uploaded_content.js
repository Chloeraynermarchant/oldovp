import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import { Redirect } from "react-router-dom";

export default class Profile extends Component {

  constructor(props){
    // Pass props to parent class
    super(props);
    // Set initial state
    this.state={
      lessons: [],
    }
  }
  componentDidMount() {
    document.body.style.background = '#eee'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'
    document.getElementsByClassName('auth-inner')[0].style.marginTop = '140px'
 

    const settings = {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    };

    const data = fetch('/learning/allLessons', settings)
      .then(response => response.json())
      .then(json => {
        console.log("res", json)
        this.setState({
          lessons: json.lessons
        });
        let requiredData1 = JSON.stringify({
          "username" : localStorage.getItem("_un"),
          "eventtype": 'View All Uploaded Content',
          "component": 'Uploaded Component',
          "description":"View all uploaded  lessons"
        });

        const settings2 = {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: requiredData1
        };
         fetch('/user/adduseractivity', settings2)
          .then(response => response.json())
          .then(json => {
            console.log("res", json)
       })
          .catch(e => {
            return e
          });
      })
      .catch(e => {
        return e
      });
  
  }
  //  Delete lesson
  deleteLesson= (lesson_id)=>{
    const settings = {
      method: 'DELETE',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    };
    fetch('/learning/specificLesson/'+lesson_id, settings)
      .then(response => response.json())
      .then(json => {
        if(json.message == "Deleted"){
          alert("Lesson deleted!")
          let updatedData=this.state.lessons.filter(function(i){return i._id !== lesson_id})
          this.setState({lessons: updatedData})
        }
        let requiredData = JSON.stringify({
          "username": localStorage.getItem("_un"),
          "eventtype": 'Delete Lesson',
          "component": 'View All Lesson',
          "description":"User deleted specific lesson"
        });
        const setting = {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: requiredData
        };
    
         fetch('/user/adduseractivity', setting)
          .then(response => response.json())
          .then(json => {
            console.log("res", json)
           
          })
          .catch(e => {  return e   });
      })
      .catch(e => {
        return e
      });
  }

  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    const {lessons}= this.state
    var count=0;
    const result =this.state.lessons.length > 0 ? this.state.lessons.map((lesson)=>{
    count+=1
      return( 
      
       <form key={lesson._id}>
        <h4>{lesson.title}</h4>
      <div className="form-group">
        <label>Duration</label> : 1hour 30 minutes
      </div>
      <div className="form-group">
        <label>Content Summary</label>
         <p>{lesson.contentsummary}</p>
      </div>
      <div className="form-group" style={{ display: 'flex' }}>
        <Link to={{pathname:`/description/${lesson._id}` ,  query:""}}
          className="btn btn-primary btn-block"
          style={{ width: '20%', float: 'left', marginRight: '10px' }}
        >
          Preview
        </Link>
        {/* <Link to={{pathname:`/description/${lesson._id}` ,  query:""}}
         */}
        <button onClick={()=>{this.deleteLesson(lesson._id)}}
          className="btn btn-primary btn-block"
          style={{
            width: '20%',
            float: 'left',
            marginRight: '10px',
            marginTop: '0px',
          }}
        disabled={localStorage.getItem('role') === 'admin'  ? false : true } title={localStorage.getItem('role') === 'admin'  ? 'Click to delete lesson' : 'Only admin can delete lesson' }
        >
          Delete
        </button>
      </div>
     
    </form>
    )
 
    }) :  "No lessons uploaded yet";
    
    return (
      <div
        className="col-lg-12 col-md-12 col-sm-12"
        style={{ paddingLeft: '30px', paddingTop: '10px' }}
      >
        <h4>Learning</h4>
        <hr />
        <div>
          {result}
        </div>
        <hr />
      <Link
        to={'/upload-content'}
        className="btn btn-primary btn-block"
        style={{ width: '40%', marginRight: '10px' }}
      >
        Upload Content
      </Link>
        {/* <form>
          <div className="form-group">
            <label>Duration</label> : 1hour 30 minutes
          </div>
          <div className="form-group">
            <label>Content Summary</label>
            <input
              type="text"
              className="form-control"
              required
              placeholder="Content Summary"
            />
          </div>
          <div className="form-group" style={{ display: 'flex' }}>
            <Link to={'/description'}
              className="btn btn-primary btn-block"
              style={{ width: '20%', float: 'left', marginRight: '10px' }}
            >
              Preview
            </Link>
            <Link to={'/description'}
              className="btn btn-primary btn-block"
              style={{
                width: '20%',
                float: 'left',
                marginRight: '10px',
                marginTop: '0px',
              }}
            >
              Go
            </Link>
          </div>
          <hr />
          <Link
            to={'/upload-content'}
            className="btn btn-primary btn-block"
            style={{ width: '40%', marginRight: '10px' }}
          >
            Upload Content
          </Link>
        </form>
       */}
      </div>
    )
  }
}
