import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import '../index.css';
import Recaptcha from 'react-recaptcha'
var reCaptchaResponse=false;
export default class SignUp extends Component {
constructor(props){
    // Pass props to parent class
    super(props);
    // Set initial state
    this.state={
      username: "",
      password: "",
      verification:''
    }
  }

  handleUsernameOnChange(event) {
    console.log("username", event.target.value)


    this.setState({
      username: event.target.value
    })
  }

  handlePasswordOnChange(event) {
    console.log("password", event.target.value)
    this.setState({
      password: event.target.value
    })
  }
  handleVerificationOnChange(event) {
  
    this.setState({
      verification: event.target.value
    })
  }
  verifyCallback(response){
        reCaptchaResponse=true
 };
  handleSubmit(event) {
    event.preventDefault()
    if (reCaptchaResponse === false) {
      console.log("errrorssss")
      alert("Please verify you are not a rebot");
      return 0;
       
   }
    let requiredData = JSON.stringify({
      "username": this.state.username,
      "password": this.state.password,
      "verification": this.state.verification,

    })
    const settings = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: requiredData
    };

    console.log("body", requiredData)
    const data = fetch('/user/signup', settings)
      .then(response => response.json())
      .then(json => {
        console.log("res", json)
        alert("Signed up successfully!")
   })
      .catch(e => {
        console.log("err")
        return e
      });
  }
  render() {
    return (
      <form onSubmit={(e) => { e.preventDefault(); this.handleSubmit(e)  }}>
        <h3>Sign Up</h3>

        <div className="form-group">
          <label>Username</label>
          <input type="text" className="form-control" placeholder="USERNAME"
           required
           onChange={(e) => { this.handleUsernameOnChange(e) }}
          />
        </div>

        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            required
            className="form-control"
            placeholder="PASSWORD"
            onChange={(e) => { this.handlePasswordOnChange(e) }}
          />
        </div>
        <div className="form-group">
          <label>Role</label>
          <input
            type="text"
            required
            className="form-control"
            placeholder="Role"
            onChange={(e) => { this.handleVerificationOnChange(e) }}
          />
        </div>
        <div className="form-group" >
              <Recaptcha
  sitekey="6LdUMv4ZAAAAAO3FZVUyZ4KfQw7XsNjl2CUIldYL"
  render="explicit"
  verifyCallback={()=>{this.verifyCallback()}}
/>
            </div>
        <div className="col-lg-12 col-md-12 col-sm-12 btns">
          <div className="col-lg-6 col-md-6 col-sm-12">
            <Link to={'/'}>
              <button className="btn btn-primary btn-block">Login</button>
            </Link>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-12">
            <button type="submit" className="btn btn-primary btn-block">
              Sign Up
            </button>
          </div>
        </div>
      </form>
    )
  }
}
