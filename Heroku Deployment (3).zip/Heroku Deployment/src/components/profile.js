import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import profile_pic from '../img/profile.png'
import { Redirect } from "react-router-dom";

export default class Profile extends Component {
  constructor(props){
    // Pass props to parent class
    super(props);
    // Set initial state
    this.state={
      name: "",
      contact: "",
      goals:"",
      role: localStorage.getItem("role"),
      resArr: [],
      activityLog: [],
      profile:''
    }
  }

  componentDidMount() {

    document.body.style.background = '#eee'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'
    document.getElementsByClassName('auth-wrapper')[0].style.marginTop = '8%'

    let payload=JSON.stringify({
      "username": localStorage.getItem("_un")
    })

    const settings = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: payload
    };

    console.log("called")
    const data = fetch('/user/getUsers', settings)
      .then(response => response.json())
      .then(json => {
        console.log("res", json)
       this.setState({
        resArr: json.user,
        name:json.user[0].name,
        goals:json.user[0].smartgoals,
        contact:json.user[0].contactdetails,
        activityLog: json.user[0].activitylog

       })
       
      })
      .catch(e => {
        return e
      });

      let requiredData = JSON.stringify({
        "username": localStorage.getItem("_un"),
        "eventtype": 'View Profile',
        "component": 'My Profile',
        "description":"User visited profile component to view profile"
      })
      const setting = {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: requiredData
      };
  
      console.log("body", requiredData)
       fetch('http://localhost:3000/user/adduseractivity', setting)
        .then(response => response.json())
        .then(json => {
          console.log("res", json)
         
     })
        .catch(e => {
          return e
        });
  }
  handleNameOnChange(event) {
    this.setState({
      name: event.target.value
    })
  }

  handleContactOnChange(event) {
    this.setState({
      contact: event.target.value
    })
  }
  handleGoalsOnChange(event) {
    this.setState({
      goals: event.target.value
    })
  }
  handleProfilePicOnChange(event){
    var ext = event.target.value.split('.').pop();
    console.log("extttttt",ext, ext == 'jpg')
    if(ext != "jpg" || ext != "jpeg" || ext != "png"  ){
     
    var file = event.target.files[0];
    var reader = new FileReader();
    var _ref=this
    reader.onloadend = function() {
      console.log('RESULT', reader.result)
      _ref.setState({
        profile: reader.result
      })
    }
    reader.readAsDataURL(file);
    }else{
      document.getElementById('profile_pic').value=null
      alert("Please upload image file")
      return  0;
    } 
  }
  handleSubmit(event) {
    event.preventDefault()
    let requiredData = JSON.stringify({
      "contactdetails": this.state.contact,
      "name": this.state.name,
      "smartgoals": this.state.goals,
      "role":localStorage.getItem("role"),
      "username":localStorage.getItem("_un"),
      "photo":this.state.profile
    })
    const settings = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: requiredData
    };
    console.log("body", requiredData)
    const data = fetch('http://localhost:3000/user/updateUser', settings)
      .then(response => response.json())
      .then(json => {
        console.log("res", json)
        document.getElementById("myImg").setAttribute('src',this.state.profile)
        let requiredData = JSON.stringify({
         "username": localStorage.getItem("_un"),
        "eventtype": 'View Profile',
        "component": 'My Profile',
        "description":"User visited profile component to view profile"
        })
        const settings2 = {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: requiredData
        };
        console.log("body", requiredData)
         fetch('http://localhost:3000/user/adduseractivity', settings2)
          .then(response => response.json())
          .then(json => {
            console.log("res", json)  
       }).catch(e => {
            return e
          });
        alert("Updated successfully!")

        
   }).catch(e => {
        return e
      });
  }
  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    let logResult= this.state.activityLog.length > 0 ? this.state.activityLog.map((log)=>{
      return(
        <tr key={log._id}>
        <td>  {log.timestamp} &nbsp;</td> 
        <td>  {log.eventtype} &nbsp;</td> 
        <td>  {log.component} &nbsp;</td> 
        <td>  {log.description}</td>

        </tr>
      )
    }) : 'No history found!';

    let result = this.state.resArr.map((resp)=>{
      return (
        <div key={resp._id}
        className="col-lg-12 col-md-12 col-sm-12"
        style={{ display: 'flex' }}
      >
        <div className="col-lg-3 col-md-2 col-sm-12">
          <img id="myImg" src={resp.photo === null || resp.photo == undefined ? this.state.profile != ''? this.state.profile: profile_pic: resp.photo } style={{ width: 'auto', height: '100px' }} />
        </div>
        <div className="col-lg-7 col-md-8 col-sm-12" style={{paddingLeft:"30px"}}>
          <form  onSubmit={(e) => { e.preventDefault(); this.handleSubmit(e) }}>
            <div className="form-group">
              <label>Name</label>
              <input required defaultValue={resp.name}  onChange={(e) => { this.handleNameOnChange(e) }} type="text"className="form-control"placeholder="Name"
              />
            </div>
            <div className="form-group">
              <label>Role</label>
              <input readOnly={true}   value={resp.verification} type="text"className="form-control"placeholder="Role"
              />
            </div>
            <div className="form-group">
              <label>Contact Details</label>
              <input defaultValue={resp.contactdetails}  onChange={(e) => { this.handleContactOnChange(e) }} required type="text"className="form-control" placeholder="Contact details"
              />
            </div>
            <div className="form-group">
              <label>Smart Goals</label>
              <input defaultValue={resp.smartgoals}  onChange={(e) => { this.handleGoalsOnChange(e) }} required type="text"className="form-control" placeholder="Smart Goals"
              />
            </div>
          <div className="form-group">
              <label>Change Profile Pic</label>
              <input type="file" id="profile_pic" placeholder="Upload file"  defaultValue={this.state.profile}  onChange={(e) => { this.handleProfilePicOnChange(e) }}  className="form-control" 
              />
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12 ">
            <button type="submit" style={{width:"130px", float:"right"}} className="btn btn-primary btn-block">
              Update Profile
            </button>
        </div>
        </form>
        </div>
      </div>
 
      )
    })
    return (
      <>
      {result}
      <br/>
      <div className="form-group" >
        <table>
          <thead>
            <th>Time Stamp</th>
            <th>Event Type</th>
            <th>Component</th>
            <th>Description</th>
          </thead>
          <tbody>
            {logResult}
          </tbody>
        </table>
        </div>
      </>
     
     )
     

  }
}
