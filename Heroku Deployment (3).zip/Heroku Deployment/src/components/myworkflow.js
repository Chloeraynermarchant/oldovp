//please provide a table reviewing the following
//admin - view all prospects
//student - view all of their generated prospects

import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import { Redirect } from "react-router-dom";

export default class QualifiedProspects extends Component {
  constructor(props) {
    // Pass props to parent class
    super(props)
    // Set initial state
    this.state = {
    
      allQualifiers:[]
    }
  }
  componentDidMount() {
    document.body.style.background = '#eee'
    
    document.getElementsByClassName('auth-wrapper')[0].style.marginTop = '100px'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'

  }
 
  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    
    return (
      <>
        <div
          className="col-lg-12 col-md-12 col-sm-12">
          <h3>My Workflow</h3>
          <hr/>
          <div >
         
         <p>
         Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
         </p>
          </div>
        </div>
      </>
    )
  }
}
