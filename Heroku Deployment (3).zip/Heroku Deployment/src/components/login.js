import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import '../index.css';
import { Redirect } from "react-router-dom";
import Recaptcha from 'react-recaptcha'
var reCaptchaResponse=false;

export default class Login extends Component {
  
constructor(props){
  // Pass props to parent class
  super(props);
  // Set initial state
  this.state={
    username: "",
    password: "",
    verification:'',
  }
}
 
handleUsernameOnChange(event) {
  console.log("username", event.target.value)


  this.setState({
    username: event.target.value
  })
}

handlePasswordOnChange(event) {
  console.log("password", event.target.value)
  this.setState({
    password: event.target.value
  })
}

  
  verifyCallback(response){
       reCaptchaResponse=true
};
    handleSubmit(event) {
  event.preventDefault()

      if (reCaptchaResponse === false) {
       console.log("errrorssss")
       alert("Please verify you are not a rebot");
       return 0;
        
    }else{
  let requiredData = JSON.stringify({
    "username": this.state.username,
    "password": this.state.password,
  })
  const settings = {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    body: requiredData
  };

  console.log("body", requiredData)
  const data = fetch('/user/login', settings)
    .then(response => response.json())
    .then(json => {
      console.log("res", json, json.message)
      if(json.message == "Incorrect Username or Password!" ){
        alert("Password is invalid!")

      }
      else if(json.message == "No user found"){
        alert("Username is invalid!")

      }
      else{
      localStorage.setItem("_un", this.state.username);
      localStorage.setItem("role", json.role);
      localStorage.setItem("loggedin", 'true');

      window.location.reload()
      return <Redirect to={"/worktoolkit"} />;
      }
 })
    .catch(e => {
      alert("Some error occured!")
      return e
    });
  }
}
  render() {

    if (localStorage.getItem("loggedin") ==="true"){
      return <Redirect to={"/worktoolkit"} />;
    } 

    return (
      <form onSubmit={(e) => { e.preventDefault(); this.handleSubmit(e) }}>
      <h3>Log In</h3>
      <div className="form-group">
        <label>Username</label>
        <input type="text" className="form-control" placeholder="USERNAME"
         required
         onChange={(e) => { this.handleUsernameOnChange(e) }}
        />
      </div>
      <div className="form-group">
        <label>Password</label>
        <input
          type="password"
          required
          className="form-control"
          placeholder="PASSWORD"
          onChange={(e) => { this.handlePasswordOnChange(e) }}
        />
      </div>
     
      <div className="form-group" >
              <Recaptcha
  sitekey="6LdUMv4ZAAAAAO3FZVUyZ4KfQw7XsNjl2CUIldYL"
  render="explicit"
  verifyCallback={()=>{this.verifyCallback()}}
/>
            </div>
      <div className="col-lg-12 col-md-12 col-sm-12 btns">
        <div className="col-lg-6 col-md-6 col-sm-12">
          
            <button type="submit" className="btn btn-primary btn-block">Login</button>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12">
        <Link to={'/sign-up'}>
          <button type="submit" className="btn btn-primary btn-block">
            Sign Up
          </button>
          </Link>

        </div>
      </div>
    </form>
 )
  }
}
