//please provide a table reviewing the following
//admin - view all prospects
//student - view all of their generated prospects

import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import { Redirect } from "react-router-dom";

export default class QualifiedProspects extends Component {
  constructor(props) {
    // Pass props to parent class
    super(props)
    // Set initial state
    this.state = {
    
      allQualifiers:[]
    }
  }
  componentDidMount() {
    document.body.style.background = '#eee'
    
    document.getElementsByClassName('auth-wrapper')[0].style.marginTop = '100px'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'

    // get  qualifiers by role
  const settings3 = {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
 
  };
   
   fetch('/qualifier/allqualifier', settings3)
    .then(response => response.json())
    .then(json => {
      if(localStorage.getItem('role')=== "student" || localStorage.getItem('role')=== "Student"){
      var filtered=  json.qualifiers.filter(function(e){ return e.user === localStorage.getItem('_un') })
      console.log("filtered", filtered)
        this.setState({
            allQualifiers: filtered
        })
      }else{
      this.setState({
        allQualifiers: json.qualifiers
      })
      }
     }).catch(e => {  return e   });
  }
  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    let qualifiersData=  this.state.allQualifiers.length > 0 ? this.state.allQualifiers.map((data => {
      return(
        <div className="form-group" key={data._id}>
        <table className="qualifierTable">
          <tbody>
          <tr>
          <th>School Type</th> <td>{data.typeschool}</td>
          <th>GCSE Result</th><td>{data.gcseresult}</td>
          </tr>
          <tr>
          <th>Governed</th> <td>{data.schoolgoverned}</td>
          <th>School Size</th> <td>{data.schoolsize}</td>
        </tr>
        <tr>
          <th>Core Subjects Stat</th> <td>{data.coresubjectstatistics}</td>
          <th>Additional Notes</th> <td>{data.notesaditionalinfo}</td>
        </tr>
        <tr>
          <th>Media Address</th> <td>{data.publishedmediaaddresses}</td>
          <th>ofsted Report</th> <td>{data.ofstedreport}</td>
        </tr>
        <tr>
          <th>Contact Name</th> <td>{data.contactname}</td>
          <th>Job Role</th> <td>{data.jobrole}</td>
        </tr>
        <tr>
          <th>Ph Extension</th> <td>{data.phoneextension}</td>
          <th>Ph #</th> <td>{data.phonenumber}</td>
        </tr>
        <tr>
          <th>Email Type</th> <td>{data.emailtype}</td>
          <th>Email</th> <td>{data.email}</td>
        </tr>
        <tr>
          <th>School Name</th> <td>{data.schoolname}</td>
          <th>School Address</th> <td>{data.schooladdress}</td>
        </tr>
        <tr>
          <th>County</th> <td>{data.country}</td>
          <th>Town/City</th> <td>{data.townorcity}</td>
        </tr>
        <tr>
          <th>Schhol Website</th> <td>{data.schoolwebsite}</td>
        </tr>
          </tbody>
        </table>
        </div>
      )
    })):'No qualifier found!';
    return (
      <>
        <div
          className="col-lg-12 col-md-12 col-sm-12"
          style={{ paddingLeft: '30px' }}>
          <h3>My Work Toolkit</h3>
          <hr/>
          <h4>Prospect Qualifier</h4>
          <div  style={{  textAlign: 'center' }}>
            <br/>
            <b style={{float:"left"}}>Table of Qualified Prospects</b>
            <br/>
            <hr/>
        <div className="form-group" >
        {qualifiersData}
        </div>
          </div>
        </div>
      </>
    )
  }
}
