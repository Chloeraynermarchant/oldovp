import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import profile_pic from '../img/profile.png'
import { Redirect } from "react-router-dom";
var student_profile='';
export default class Profile extends Component {
  constructor(props){
    // Pass props to parent class
    super(props);
    // Set initial state
    this.state={
      name: "",
      contact: "",
      goals:"",
      role: '',
      resArr: [],
      username:''
     
    }
  }

  componentDidMount() {
    
    document.body.style.background = '#eee'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'
    document.getElementsByClassName('auth-wrapper')[0].style.marginTop = '8%'

    let payload=JSON.stringify({
      "username": this.props.match.params.name
    })

    const settings = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: payload
    };

    console.log("called")
    const data = fetch('/user/getUsers', settings)
      .then(response => response.json())
      .then(json => {
        console.log("get users ", json)
       this.setState({
        resArr: json.user,
        name:json.user[0].name,
        goals:json.user[0].smartgoals,
        contact:json.user[0].contactdetails,
        username:json.user[0].username,
        role: json.user[0].verification
       })
       student_profile=json.user[0].photo
      })
      .catch(e => {
        return e
      });
       
      let requiredData = JSON.stringify({
        "username": localStorage.getItem("_un"),
        "eventtype": 'Update Student Profile',
        "component": 'Uodate Profile',
        "description":"Developer visited specific user profile component and updated  profile"
      })
      const setting = {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: requiredData
      };
  
      console.log("body", requiredData)
       fetch('/user/adduseractivity', setting)
        .then(response => response.json())
        .then(json => {
          console.log("res", json)
         
     })
        .catch(e => {
          return e
        });
  }
  handleNameOnChange(event) {
    this.setState({
      name: event.target.value
    })
  }

  handleContactOnChange(event) {
    this.setState({
      contact: event.target.value
    })
  }
  handleGoalsOnChange(event) {
    this.setState({
      goals: event.target.value
    })
  }
  
  handleSubmit(event) {
    event.preventDefault()
    let requiredData = JSON.stringify({
      "contactdetails": this.state.contact,
      "name": this.state.name,
      "smartgoals": this.state.goals,
      "role":this.state.role,
      "username":this.state.username,
      "photo":student_profile
    })
    const settings = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: requiredData
    };
    console.log("body", requiredData)
    const data = fetch('/user/updateUser', settings)
      .then(response => response.json())
      .then(json => {
        console.log("res", json)
     
        let requiredData = JSON.stringify({
          "username": localStorage.getItem("_un"),
          "eventtype": 'Update Student Profile',
          "component": 'Uodate Profile',
          "description":"Developer visited specific user profile component and updated  profile"
        })
        const settings2 = {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: requiredData
        };
        console.log("body", requiredData)
         fetch('/user/adduseractivity', settings2)
          .then(response => response.json())
          .then(json => {
            console.log("res", json)  
       }).catch(e => {
            return e
          });
        alert("Updated successfully!")

        
   }).catch(e => {
        return e
      });
  }
  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    let result = this.state.resArr.map((resp)=>{
      return (
        <div key={resp._id}
        className="col-lg-12 col-md-12 col-sm-12"
        style={{ display: 'flex' }}
      >
        <div className="col-lg-3 col-md-2 col-sm-12">
          <img id="myImg" src={resp.photo === null || resp.photo == undefined ? this.state.profile != ''? this.state.profile: profile_pic: resp.photo } style={{ width: 'auto', height: '100px' }} />
        </div>
        <div className="col-lg-7 col-md-8 col-sm-12" style={{paddingLeft:"30px"}}>
          <form  onSubmit={(e) => { e.preventDefault(); this.handleSubmit(e) }}>
            <div className="form-group">
              <label>Name</label>
              <input required defaultValue={resp.name}  onChange={(e) => { this.handleNameOnChange(e) }} type="text"className="form-control"placeholder="Name"
              />
            </div>
            <div className="form-group">
              <label>Role</label>
              <input readOnly={true}   value={resp.verification} type="text"className="form-control"placeholder="Role"
              />
            </div>
            <div className="form-group">
              <label>Contact Details</label>
              <input defaultValue={resp.contactdetails}  onChange={(e) => { this.handleContactOnChange(e) }} required type="text"className="form-control" placeholder="Contact details"
              />
            </div>
            <div className="form-group">
              <label>Smart Goals</label>
              <input defaultValue={resp.smartgoals}  onChange={(e) => { this.handleGoalsOnChange(e) }} required type="text"className="form-control" placeholder="Smart Goals"
              />
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12 ">
            <button type="submit" style={{width:"130px", float:"right"}} className="btn btn-primary btn-block">
              Update Profile
            </button>
        </div>
        </form>
        </div>
      </div>
 
      )
    })
    return (
      <>
      {result}
      <br/>
   
      </>
     
     )
     

  }
}
