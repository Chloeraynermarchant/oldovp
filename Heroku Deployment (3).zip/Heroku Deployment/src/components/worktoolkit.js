import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import { Redirect } from "react-router-dom";

export default class Profile extends Component {
  state={
    allUsers:[]
  };
  componentDidMount() {
    document.body.style.background = '#eee'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'
    document.getElementsByClassName('auth-inner')[0].style.marginTop = '140px'
    if(localStorage.getItem('role') ==="developer" || localStorage.getItem('role') ==="Developer"){
      //  get all users
  const settings3 = {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
 
  };
   
   fetch('/user/allUsers', settings3)
    .then(response => response.json())
    .then(json => {
      console.log("all users", json)
      var filtered=  json.users.filter(function(e){ return e.username !== localStorage.getItem('_un') })

      this.setState({
        allUsers: filtered
      })
     }).catch(e => {  return e   });
    }
  }
  handlDelete(username){
    let payload=JSON.stringify({
      "username": username
    })
    const settings3 = {
      method: 'DELETE',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body:payload
    };
     fetch('/user/deleteUser', settings3)
      .then(response => response.json())
      .then(json => {
        console.log("all users", json)
        var filtered=  this.state.allUsers.filter(function(e){ return e.username !== username })
  
        this.setState({
          allUsers: filtered
        })
       }).catch(e => {  return e   });
      }
  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    let showUsers= this.state.allUsers.length > 0 ? this.state.allUsers.map((data)=>{
      return(
        <tr key={data._id}>
        <td>{data.name}</td>
        <td>{data.username}</td>
        <td>{data.contactdetails}</td>
        <td>{data.smartgoals}</td>
        <td>{data.verification}</td>
        <td  style={{maxWidth:"100px"}}>
        <Link to={`/updatestudent/${data.username}`} className="btn btnEdit"    style={{width:"60px"}} >
        Edit
      </Link>  &nbsp;   &nbsp; 
      <button className="btn btnDel" onClick={()=>{this.handlDelete(data.username)}}  style={{width:"70px"}} >
        Delete
      </button>
        </td>
      </tr>
      )

    }): 'No user found!'
    return (
      <>
      <div
        className="container"
        style={{ paddingLeft: '30px', paddingTop: '10px' }}
      >
        <h4>My Work Toolkit</h4>
        <hr />
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-12">
            <div className="card">
              <div className="body toolkitBtns">
                <Link to={'/qualifier1'}>Prospect Qualifier</Link>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-12">
            <div className="card">
              <div className="body toolkitBtns">
              <Link to={'/qualifiedprospect'}>Prospects</Link>
              </div>
            </div>
          </div>
        </div>
        <div className="row" style={{ paddingTop: '10px' }}> 
          <div className="col-lg-6 col-md-6 col-sm-12">
            <div className="card">
              <div className="body toolkitBtns">
                <Link>Market Research</Link>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-12">
            <div className="card">
              <div className="body toolkitBtns">
              <Link to={'/myworkflow'}>My Workflow</Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="container" id="developer_view"
        style={{ paddingLeft: '30px', paddingTop: '10px', display:localStorage.getItem("role") == 'developer' || localStorage.getItem("role") == 'Developer' ? 'block': 'none' }}
      >
        <h5>All Users</h5>
      <br/>
      <div className="form-group" >
        <table style={{width:"100%"}} id="usersTable"> 
          <thead style={{textAlign:'center'}}>
            <th>Name</th>
            <th>Username</th>
            <th>Contact</th>
            <th>Goals</th>
            <th>Role</th>

            <th>Actions</th>
          
          </thead>
          <tbody>
            {showUsers}
          </tbody>
        </table>
        </div>
        </div>
      </>
    )
  }
}
