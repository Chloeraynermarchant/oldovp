import React, { Component } from 'react'
import { BrowserRouter as Router, Link } from 'react-router-dom'
import { Redirect } from "react-router-dom";

export default class Profile extends Component {
  componentDidMount() {
    console.log("id", this.props.match.params.id)
    document.body.style.background = '#eee'
    document.getElementsByClassName('auth-inner')[0].style.width = '50%'
    document.getElementsByClassName('auth-inner')[0].style.borderRadius = '0%'
    document.getElementsByClassName('auth-inner')[0].style.boxShadow = 'none'
    document.getElementsByClassName('auth-inner')[0].style.marginTop = '5%'
    const settings = {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    };
    const data = fetch('/learning/specificLesson/'+this.props.match.params.id, settings)
      .then(response => response.json())
      .then(json => {
        console.log("res", json)
        var video = document.getElementById("video");
       video.src =   json.lesson[0].uploadedfile;
       document.getElementById('content').innerHTML=json.lesson[0].contentsummary
        this.setState({
          lessons: json.lesson
        })

        let requiredData = JSON.stringify({
          "username": localStorage.getItem("_un"),
          "eventtype": 'View Lesson',
          "component": 'View Specific Lesson',
          "description":"User viewed specific lesson"
        })
        const setting = {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: requiredData
        };
    
        console.log("body", requiredData)
         fetch('/user/adduseractivity', setting)
          .then(response => response.json())
          .then(json => {
            console.log("res", json)
           
       })
          .catch(e => {
            return e
          });

      })
      .catch(e => {
        return e
      });

    
  }
  render() {
    if (localStorage.getItem("loggedin") !== "true"){
      return <Redirect to={"/"} />;
    }
    return (
      <div
        className="col-lg-12 col-md-12 col-sm-12"
        style={{ paddingLeft: '30px', paddingTop: '10px' }}
      >
        <h4>Learning</h4>
        <hr />
        <h4>Lesson1</h4>
        <form>
          <div className="form-group">
          <video width="100%" height="345" autoPlay={true} controls  id="video"></video>
  </div>
          <div className="form-group" >
          <label>Written Content</label><br/>
        <p id="content">

        </p>
          </div>
          <div className="form-group" >
          <label>Comments</label><br/>
          <textarea col="30" row="5" className="form-control" placeholder="Comments" >
           </textarea>
          </div>
        </form>
      </div>
    )
  }
}
