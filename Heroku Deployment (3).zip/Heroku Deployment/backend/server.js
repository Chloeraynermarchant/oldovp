const express = require('express');
var cors = require('cors')

const mongoose = require('mongoose');
const app = express();

//import routes 

//import controllers 
const qualifierController= require('./controllers/qualifierController');
const userController= require('./controllers/userController');
const learningController= require('./controllers/learningController');
const bodyParser = require('body-parser');
const { use } = require('./controllers/qualifierController');


//middleware
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(express.json());
app.use(cors());

const port = process.env.PORT || 3000;

const buildPath = path.join(__dirname, '..', 'build');
app.use(express.static(buildPath));
//connecting build to heroku 
if(process.env.NODE_ENV === 'production'){
    app.use(express.static('frontend/build'));
}

//const url = 'mongodb://localhost:27017/MERNDB';
const url = `mongodb+srv://chayce:Mo7ydsnfc@ovp.fezks.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`;
const connectionParams={
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true 
}

app.get('/', (req, res) =>{
    res.send("Hello world")});


//MongoDB
const initDataBase = async () => {
    database = await mongoose.connect(url, connectionParams);
    if (database) { 
        console.log('Succesfully connected to my DB');
    } else {
        console.log("Error connecting to my DB");
    }
}

initDataBase().then(() => {
    app.use('/user',userController);
    app.use('/learning',learningController);
    app.use('/qualifier',qualifierController);
    app.listen(port);
    console.log(`listening on port ${port}`);
});