const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, 
    password: String,
    verification: String,
    name: String,
    role: String,
    contactdetails:String,
    smartgoals:String,
    photo:String,
    activitylog:[{
        timestamp:String,   
        eventtype:String,
        component:String,
        description:String,
    }],
}); 
const userModel = mongoose.model('user', userSchema);
module.exports = userModel;