const express = require("express");
const userModel = require("../models/user");
const router = express.Router();
router.use(express.json());
var bcrypt = require("bcryptjs");
const config = require("../configuration/config");
router.post("/signup", (req, res) => {
  var hashedPassword = bcrypt.hashSync(req.body.password, 8);
  var newUser = {
    username: req.body.username,
    password: hashedPassword,
    verification: req.body.verification,
    contactdetails:"",
    smartgoals:"",
    name:""
  };
  userModel.create(newUser, (err, user) => {
    if (err) {
      res.status(500);
    } else {
      res.status(200).send({ messsage: "user created" });
    }
  });
});

router.post("/login", (req, res) => {
  userModel.findOne(
    { username: req.body.username},
    function (err, user) {
      if (err) {
        res.status(500).send({ message: "Error on Server" }); // send server error code
      }
      if (user) {
        var passwordIsValid = bcrypt.compareSync(
          req.body.password,
          user.password
        );
        if (!passwordIsValid) {
          res.status(404).send({ message: "Incorrect Username or Password!" });
        }else{

        res
          .status(200)
          .send({ message: "Acknowledge", role: user.verification });
        }
      }
      else if (!user) {
        res.status(404).send({ message: "No user found" });
      }
    }
  );
});

router.post('/updateUser', (req, res) => {
   
    var user = {
        username:req.body.username
    }

    var updateUser = {
        name: req.body.name,
        role: req.body.role,
        contactdetails: req.body.contactdetails,
        smartgoals: req.body.smartgoals,
        photo: req.body.photo
    }
    userModel.updateOne(user,updateUser, (err, user) => {
        if (err) {
            res.status(500).send("Error in updating User.");
        }
        else {
            res.status(200).send({"messsage":"Acknowledged"}); 
        }
    });

}); 

router.post("/adduseractivity", function (req, res) {
    userModel.findOneAndUpdate(
      { username: req.body.username },
      {
        $addToSet: {
            activitylog: 
            {
                timestamp:new Date(),   
                eventtype:req.body.eventtype,
                component:req.body.component,
                description:req.body.description
            }
        }
      },
      function (err, user) {
        if (err)
          return res
            .status(500)
            .send({ message: "Error in adding an acitivity." });
        res.status(200).send({ message: "Acknowledged" });
      }
    );
});

router.post("/getUsers", (req, res) => {
    userModel.find({username:req.body.username}, (err, user) => {
      if (err) {
        res.send(500);
      } else {
        res.status(200).send({ user: user });
      }
    });
});

//delete user 
router.delete("/deleteUser", (req, res) => {
  userModel.findOneAndDelete({username:req.body.username}, (err, user) => {
    if (err) {
      res.send(500);
    } else {
      res.status(200).send({ message: "Deleted" });
    }
  });
});


router.get("/allUsers", (req, res) => {
  userModel.find({}, (err, users) => {
    if (err) {
      res.send(500);
    } else {
      res.status(200).send({ users: users });
    }
  });
});

module.exports = router;
